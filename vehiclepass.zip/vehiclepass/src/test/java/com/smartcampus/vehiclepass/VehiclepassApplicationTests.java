package com.smartcampus.vehiclepass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclepassApplicationTests {

	@Test
	void contextLoads() {
	}

}
